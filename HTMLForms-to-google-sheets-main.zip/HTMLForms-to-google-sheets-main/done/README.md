# HTMLForms-to-google-sheets
How to connect your HTML forms to google spreadsheets
